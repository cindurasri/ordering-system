const orders = [
    {
        orderNumber: "12345",
        status: "Delivered",
        total: 18
    },
    {
        orderNumber: "12346",
        status: "In Progress",
        total: 25
    }
];

// Function to create and append order elements
function displayOrders() {
    const container = document.getElementById("ordersContainer");
    
    orders.forEach(order => {
        // Create order elements
        const orderDiv = document.createElement("div");
        const orderTitle = document.createElement("h3");
        const statusP = document.createElement("p");
        const totalP = document.createElement("p");
        const hr = document.createElement("hr");

        // Set content
        orderTitle.textContent = `Order #${order.orderNumber}`;
        statusP.textContent = `Status: ${order.status}`;
        totalP.textContent = `Total: $${order.total}`;

        // Append elements to orderDiv
        orderDiv.appendChild(orderTitle);
        orderDiv.appendChild(statusP);
        orderDiv.appendChild(totalP);
        orderDiv.appendChild(hr);

        // Append orderDiv to container
        container.appendChild(orderDiv);
    });

    // Remove the last hr element to avoid extra line at the end
    const lastHr = container.querySelector("hr:last-child");
    if (lastHr) {
        lastHr.remove();
    }
}

// Call the function when the page loads
window.onload = displayOrders;