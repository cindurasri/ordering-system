// Sample sales data (can be replaced with a backend API)
const salesData = {
    totalSales: 1500,
    popularItems: [
        { name: "Margherita Pizza", orders: 30 },
        { name: "Cheese Burger", orders: 25 },
        { name: "Pasta Alfredo", orders: 20 }
    ]
};

// Function to load report data dynamically
function loadReports() {
    document.getElementById("total-sales").textContent = `$${salesData.totalSales}`;

    const popularItemsList = document.getElementById("popular-items");
    popularItemsList.innerHTML = ""; // Clear previous content

    salesData.popularItems.forEach(item => {
        const listItem = document.createElement("li");
        listItem.textContent = `${item.name} - ${item.orders} orders`;
        popularItemsList.appendChild(listItem);
    });
}

// Load reports on page load
document.addEventListener("DOMContentLoaded", loadReports);
