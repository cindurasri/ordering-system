// Sample orders data (can be replaced with a backend API)
const orders = [
    { id: 12345, status: "Delivered" },
    { id: 12346, status: "In Progress" },
    { id: 12347, status: "Pending" }
];

// Function to display orders dynamically
function loadOrders() {
    const ordersList = document.getElementById("orders-list");
    ordersList.innerHTML = ""; // Clear previous content

    orders.forEach(order => {
        const orderDiv = document.createElement("div");
        orderDiv.classList.add("order-item");

        orderDiv.innerHTML = `
            <h3>Order #${order.id} - <span class="status">${order.status}</span></h3>
            ${order.status !== "Delivered" ? `<button class="mark-delivered" data-id="${order.id}">Mark as Delivered</button>` : ""}
            <button class="view-details" data-id="${order.id}">View Details</button>
            <hr>
        `;

        ordersList.appendChild(orderDiv);
    });

    attachEventListeners();
}

// Function to update order status
function markAsDelivered(orderId) {
    const order = orders.find(o => o.id === orderId);
    if (order) {
        order.status = "Delivered";
        loadOrders(); // Refresh UI
        alert(`Order #${orderId} marked as Delivered.`);
    }
}

// Function to handle viewing order details
function viewOrderDetails(orderId) {
    alert(`Viewing details for Order #${orderId}`);
}

// Attach event listeners to buttons
function attachEventListeners() {
    document.querySelectorAll(".mark-delivered").forEach(button => {
        button.addEventListener("click", function () {
            const orderId = parseInt(this.getAttribute("data-id"));
            markAsDelivered(orderId);
        });
    });

    document.querySelectorAll(".view-details").forEach(button => {
        button.addEventListener("click", function () {
            const orderId = parseInt(this.getAttribute("data-id"));
            viewOrderDetails(orderId);
        });
    });
}

// Load orders on page load
document.addEventListener("DOMContentLoaded", loadOrders);
