function showRegister() {
    document.getElementById("register-section").style.display = "block";
}

function login() {
    let userType = document.getElementById("userType").value;
    let email = document.getElementById("email").value;
    let password = document.getElementById("password").value;

    if (email && password) {
        if (userType === "user") {
            window.location.href = "user-dashboard.html";
        } else if (userType === "admin") {
            window.location.href = "admin-dashboard.html";
        }
    } else {
        alert("Please enter valid credentials");
    }
}

function register() {
    let name = document.getElementById("name").value;
    let email = document.getElementById("register-email").value;
    let password = document.getElementById("register-password").value;

    if (name && email && password) {
        alert("Registration successful! Please login.");
        document.getElementById("register-section").style.display = "none";
    } else {
        alert("All fields are required!");
    }
}
