document.addEventListener("DOMContentLoaded", function () {
    updateTotal();

    // Handle quantity change
    document.querySelectorAll(".cart-item input[type='number']").forEach(input => {
        input.addEventListener("change", updateTotal);
    });

    // Handle item removal
    document.querySelectorAll(".cart-item button").forEach(button => {
        button.addEventListener("click", function () {
            this.parentElement.remove();
            updateTotal();
        });
    });

    // Handle order placement
    document.querySelector(".total button").addEventListener("click", function () {
        alert("Order placed successfully!");
        document.querySelector(".container").innerHTML = "<h2>Thank you for your order!</h2>";
    });
});

function updateTotal() {
    let total = 0;

    document.querySelectorAll(".cart-item").forEach(item => {
        let priceText = item.querySelector("p").textContent;
        let price = parseFloat(priceText.replace("Price: $", ""));
        let quantity = item.querySelector("input").value;
        total += price * quantity;
    });

    document.querySelector(".total h2").textContent = `Total: $${total.toFixed(2)}`;
}
