fetch('./new.json')
    .then(response => response.json())
    .then(data => {
        let newsContainer = document.getElementById('news');
        data.news.forEach(newsItem => {
            let newsElement = document.createElement('div');
            newsElement.classList.add('news-item');
            newsElement.innerHTML = `
                <h2>${newsItem.title}</h2>
                <p><strong>Date:</strong> ${newsItem.date}</p>
                <p>${newsItem.description}</p>
            `;
            newsContainer.appendChild(newsElement);
        });
    })
    .catch(error => console.error("Error loading news:", error));

    document.addEventListener("DOMContentLoaded", function() {
        fetch("new.json")
            .then(response => response.json())
            .then(news => {
                const newsList = document.getElementById("news-list");
                news.forEach(article => {
                    const newsItem = document.createElement("div");
                    newsItem.classList.add("news-item");
                    newsItem.innerHTML = `
                        <h2>${article.title}</h2>
                        <p><strong>Date:</strong> ${article.date}</p>
                        <p>${article.description}</p>
                    `;
                    newsList.appendChild(newsItem);
                });
            })
            .catch(error => console.error("Error loading news:", error));
    });
    