document.getElementById('contactForm').addEventListener('submit', function (e) {
    e.preventDefault();

    let name = document.getElementById('name').value;
    let email = document.getElementById('email').value;
    let message = document.getElementById('message').value;

    let contactData = {
        name: name,
        email: email,
        message: message
    };

    fetch('contacts.json')
        .then(response => response.json())
        .then(data => {
            data.contacts.push(contactData);
            return fetch('contacts.json', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(data)
            });
        })
        .then(() => {
            alert('Your message has been sent!');
            document.getElementById('contactForm').reset();
        })
        .catch(error => console.error("Error saving contact data:", error));
});
