let currentSlide = 0;

function showSlides() {
    let slides = document.getElementsByClassName("slides");
    for (let i = 0; i < slides.length; i++) {
        slides[i].style.display = "none";
    }
    currentSlide++;
    if (currentSlide > slides.length) {
        currentSlide = 1;
    }
    slides[currentSlide - 1].style.display = "block";
    setTimeout(showSlides, 3000); // Change slide every 3 seconds
}

window.onload = function () {
    showSlides();
};
