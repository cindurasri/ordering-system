fetch('./events.json')
    .then(response => response.json())
    .then(data => {
        let eventsContainer = document.getElementById('events');
        data.events.forEach(event => {
            let eventElement = document.createElement('div');
            eventElement.classList.add('event-item');
            eventElement.innerHTML = `
                <h2>${event.title}</h2>
                <p><strong>Date:</strong> ${event.date}</p>
                <p>${event.description}</p>
            `;
            eventsContainer.appendChild(eventElement);
        });
    })
    .catch(error => console.error("Error loading events:", error));
document.addEventListener("DOMContentLoaded", function() {
    fetch("events.json")
        .then(response => response.json())
        .then(events => {
            const eventsList = document.getElementById("events-list");
            events.forEach(event => {
                const eventItem = document.createElement("div");
                eventItem.classList.add("event-item");
                eventItem.innerHTML = `
                    <h2>${event.title}</h2>
                    <p><strong>Date:</strong> ${event.date}</p>
                    <p>${event.description}</p>
                `;
                eventsList.appendChild(eventItem);
            });
        })
        .catch(error => console.error("Error loading events:", error));
});
