fetch('./contacts.json')
    .then(response => response.json())
    .then(data => {
        let contactsList = document.getElementById('contactsList');
        data.contacts.forEach(contact => {
            let contactElement = document.createElement('div');
            contactElement.classList.add('contact-item');
            contactElement.innerHTML = `
                <p><strong>Name:</strong> ${contact.name}</p>
                <p><strong>Email:</strong> ${contact.email}</p>
                <p><strong>Message:</strong> ${contact.message}</p>
                <hr>
            `;
            contactsList.appendChild(contactElement);
        });
    })
    .catch(error => console.error("Error loading contacts:", error));
