
document.getElementById('switch-to-login').addEventListener('click', function() {
    document.getElementById('signup-container').style.display = 'none';
    document.getElementById('login-container').style.display = 'flex';
});

document.getElementById('sign-up-btn').addEventListener('click', function() {
    const role = document.getElementById('role').value;
    const name = document.querySelector('#signup-container input[type="text"]').value;
    const email = document.querySelector('#signup-container input[type="email"]').value;
    const password = document.querySelector('#signup-container input[type="password"]').value;

    if (name && email && password) {
        const storedData = JSON.parse(localStorage.getItem('userData'));
        
        if (storedData && storedData.email === email) {
            alert('Email already exists. Please log in.');
        } else {
            localStorage.setItem('userData', JSON.stringify({ role, name, email, password }));
            alert('Sign Up Successful!');
            if (role === 'admin') {
                window.location.href = 'admin_dashboard.html';
            } else {
                window.location.href = 'user-dashboard.html';
            }
        }
    } else {
        alert('Please fill in all fields.');
    }
});

document.getElementById('login-btn').addEventListener('click', function() {
    const role = document.getElementById('login-role').value;
    const email = document.querySelector('#login-container input[type="email"]').value;
    const password = document.querySelector('#login-container input[type="password"]').value;
    const storedData = JSON.parse(localStorage.getItem('userData'));

    if (storedData && storedData.email === email && storedData.password === password && storedData.role === role) {
        if (storedData.role === 'admin') {
            window.location.href = 'admin_dashboard.html';
        } else {
            window.location.href = 'user-dashboard.html';
        }
    } else {
        alert('Invalid credentials. Please try again.');
    }
});
